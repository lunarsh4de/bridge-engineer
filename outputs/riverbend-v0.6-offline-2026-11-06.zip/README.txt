Bridge Engineer - Riverbend v0.6 / 桥梁工程师 Riverbend v0.6
================================================================

ENGLISH
-------
Launch: keep this folder intact, then double-click index.html in a current
desktop Chromium-based browser. No server, account, API key or network is
required. Optional external reading links need a connection only when opened.

The package contains an eight-crossing campaign and a separate Free Build
laboratory. Campaign and sandbox work are stored locally when browser storage
is available. Help > Settings can export progress before moving computers.

Model limits: this is an educational axial-member simulation, not engineering
analysis software. It idealizes pin joints, self-weight, axial deformation,
simplified failure and tension-only cable. It omits beam bending, realistic
buckling shapes, joint failure, fatigue, wind and full wheel contact. The 12 cm
drop rule and material values are game rules. Passing is not proof of a safe or
optimal real bridge, and completion is not proof of learning outcomes.

The four story PNGs are local rasterizations of original code-authored SVG
illustrations. They are native project artwork, not successful API-generated
images and not downloaded third-party artwork. See assets/ART-PROVENANCE.md.

中文
----
启动：保持文件夹完整，使用当前桌面版 Chromium 内核浏览器双击
index.html。无需服务器、安装、账号、API Key 或联网。只有主动打开外部
参考链接时才需要网络。

游戏包含八关主线和独立 Free Build 实验室。浏览器允许本地存储时会保存
主线与沙盒进度；换电脑前可在 Help > Settings 导出进度。

模型边界：这是教学用轴向构件仿真，不是工程分析软件。它简化了铰接节点、
自重、轴向变形、构件失效和只受拉缆索，省略梁弯曲、真实屈曲形态、节点
破坏、疲劳、风和完整轮胎接触。12 cm 下落与材料参数是游戏规则。通关不
证明真实桥梁安全或数学最优，也不自动证明学习成效。

四张故事 PNG 是项目原创代码绘制 SVG 的本地栅格化版本，不是成功的 API
生图，也不是下载的第三方美术。详见 assets/ART-PROVENANCE.md。

Licenses and teaching references
--------------------------------
Phaser's MIT notice is in vendor/PHASER-LICENSE.md. Optional teacher-facing
design notes and the numerical audit are in teacher-docs/; they are not needed
to run the game.
